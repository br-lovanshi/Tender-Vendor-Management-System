package com.project.exception;

public class VendorException extends Exception{

	public VendorException() {
		// TODO Auto-generated constructor stub
	}
	
	public VendorException(String message) {

		super(message);
	}
	

}
