package com.project.exception;

public class TenderException extends Exception{

	public TenderException() {
		// TODO Auto-generated constructor stub
	}
	
	
	public TenderException(String message) {
		super(message);
	}
}
