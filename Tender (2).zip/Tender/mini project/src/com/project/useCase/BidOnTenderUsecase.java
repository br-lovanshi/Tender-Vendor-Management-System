package com.project.useCase;

import java.util.Scanner;

import com.project.dao.TenderDao;
import com.project.dao.TenderDaoImp;

public class BidOnTenderUsecase {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		

	}

}
