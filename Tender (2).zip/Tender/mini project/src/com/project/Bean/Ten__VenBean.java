package com.project.Bean;

public class Ten__VenBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
